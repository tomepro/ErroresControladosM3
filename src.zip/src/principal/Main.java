package principal;

import complementos.Identificador;
import complementos.Parking;
import complementos.Plaza;
import complementos.Ticket;
import java.util.Scanner;

/**
 *
 * @author marctomjim
 */
public class Main {

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        boolean todoCorrecto = false;
        String tipoVehiculo = "";
        String matricula = "";
        String color = "";

        Parking parking = new Parking("PR123", "C/ Monlau 6, Barcelona", "+34 666 88 66",
                25, 10, 2.5, 1.5, 3.0);

        System.out.println("Bienvenido al sistema de Parking");

        System.out.print("Ingrese el tipo de vehiculo (coche, moto o camion): ");
        tipoVehiculo = scanner.nextLine().toLowerCase();

        if (tipoVehiculo.trim().isEmpty()) {
            System.out.println("El tipo de vehículo no puede estar vacío.");
        }

        System.out.print("Ingrese la matricula: ");
        matricula = scanner.nextLine();

        System.out.print("Ingrese el color: ");
        color = scanner.nextLine();

        todoCorrecto = true;

        Identificador vehiculo = new Identificador(tipoVehiculo, matricula, color);

        String codigoPlaza = parking.asignarPlaza(vehiculo);
        if (codigoPlaza == null) {
            System.out.println("No hay plazas disponibles.");
            return;
        }

        System.out.print("Ingrese el tiempo estimado de estacionamiento (en horas): ");
        int tiempoEstacionado = scanner.nextInt();

        double importe = parking.calcularImporte(tipoVehiculo, tiempoEstacionado);

        Ticket ticket = new Ticket(parking.getParkingId(), codigoPlaza, tipoVehiculo, matricula, color, tiempoEstacionado, importe);

        System.out.println(ticket.generarDetalle());

        System.out.println("\n ---CONFIRMACION DEL PAGO---");
        System.out.println(ticket.generarDetalle());

    }
}
